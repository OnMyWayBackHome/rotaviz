# ht16k33
This library is used to allow an arduino like platform talk to the holtek ht16k33 chip
to do things like turn on/off LEDs or scan keys


